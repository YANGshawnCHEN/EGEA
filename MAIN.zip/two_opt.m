% function path = two_opt(path, cost)
%     %2-opt局部搜索
%     improved = true;
%     while improved
%         improved = false;
%         for i = 1:length(path)-2
%             for j = i+2:length(path)-1
%                 if cost(path(i),path(i+1)) + cost(path(j),path(j+1)) > ...
%                    cost(path(i),path(j)) + cost(path(i+1),path(j+1))
%                     path(i+1:j) = fliplr(path(i+1:j));
%                     improved = true;
%                 end
%             end
%         end
%     end
% end

function [count, new_path] = two_opt(path, cost, count)
    % 输入:
    %   path: 初始路径 (1 x N 向量)
    %   cost: 距离矩阵 (N x N 对称矩阵, cost(i,j) 是城市i到城市j的距离)
    % 输出:
    %   new_path: 优化后的路径
    %   total_evaluated_nodes: 评估过程中访问的总城市节点个数（每次2-opt交换评估4个节点）

    new_path = path;
    n = length(path);
    improved = true;
    total_evaluated_nodes = 0;

    while improved
        improved = false;
        for i = 1:(n-2)
            for j = (i+2):n
                % 当前边的距离: path(i)->path(i+1) 和 path(j)->path(j+1 [mod n])
                a = new_path(i); b = new_path(i+1);
                c = new_path(j); d = new_path(mod(j, n) + 1); % 处理环形路径

                % 计算当前距离和交换后的距离
                original_cost = cost(a, b) + cost(c, d);
                new_cost = cost(a, c) + cost(b, d);

                % 如果交换后更优，则翻转路径 i+1 到 j 的部分
                if new_cost < original_cost
                    new_path(i+1:j) = flip(new_path(i+1:j));
                     improved = true;
                end
				 % 每次2-opt评估了4个节点（a, b, c, d）评估次数每次+4;保存2-opt整体运算节点数
                total_evaluated_nodes = total_evaluated_nodes + 4;
            end
        end
    end
	count=count+total_evaluated_nodes/n; %%传入的当前评估次数+（opt运算节点累加数/该问题城市数==评估次数）
end
