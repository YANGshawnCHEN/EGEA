function child = erx(parent1, parent2)
    % 输入：两个父代路径parent1和parent2
    % 输出：通过边重组生成的子代路径
    
    n = length(parent1);
    child = zeros(1, n);
    
    % 1. 构建边表（Edge Table）
    edgeTable = cell(1, n); % 每个城市对应的相邻边集合
    for i = 1:n
        % 处理父代1的边（环状路径）
        prev1 = parent1(mod(i-2, n) + 1);
        next1 = parent1(mod(i, n) + 1);
        edgeTable{parent1(i)} = unique([prev1, next1]);
        
        % 处理父代2的边（环状路径）
        prev2 = parent2(mod(i-2, n) + 1);
        next2 = parent2(mod(i, n) + 1);
        existingEdges = edgeTable{parent2(i)};
        edgeTable{parent2(i)} = unique([existingEdges, prev2, next2]);
    end
    
    % 2. 随机选择起始城市
    currentCity = parent1(randi(n));
    child(1) = currentCity;
    visited = false(1, n);
    visited(currentCity) = true;
    
    % 3. 逐步构建子代路径
    for k = 2:n
        % 获取当前城市的可用相邻边
        neighbors = edgeTable{currentCity};
        % 过滤已访问的城市
        available = neighbors(~visited(neighbors));
        
        if ~isempty(available)
            % 选择具有最少可用边的邻居
            minEdges = inf;
            bestCandidate = [];
            for candidate = available
                candidateEdges = length(edgeTable{candidate});
                if candidateEdges < minEdges
                    minEdges = candidateEdges;
                    bestCandidate = candidate;
                end
            end
            nextCity = bestCandidate;
        else
            % 随机选择未访问的城市（处理死锁）
            unvisited = find(~visited);
            nextCity = unvisited(randi(length(unvisited)));
        end
        
        % 更新路径和访问标记
        child(k) = nextCity;
        visited(nextCity) = true;
        currentCity = nextCity;
    end
end