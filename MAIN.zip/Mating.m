function [count,offspring]=Mating(sumdistance,pop,count,varargin)
 global cost
[popsize,m]=size(pop);
D=m-1;
 cross_rate=0.9;
 mutation_rate=0.9;
for i=1:popsize
    offspring(i,1:D)=randperm(D);
    offspring(i,D+1)=offspring(i,1);
end
% pop=unique(pop,'rows');
% [popsize1,~]=size(pop);
for k=1:popsize
    randomRow = randi(popsize,2,1);
    tourPopDistances= sumdistance(randomRow,:);
    varargin = cellfun(@(S)reshape(S,length(varargin{1}),1),varargin,'UniformOutput',false);
    [~,rank] = sortrows([varargin{:}]);
    [~,rank] = sort(rank);
    [~,best] = min(rank(randomRow),[],1);
    index    = randomRow(best);
    pop1=pop(index,:);
    randomRow = randi(popsize,2,1);
    tourPopDistances= sumdistance(randomRow,:);
    [~,rank] = sortrows([varargin{:}]);
    [~,rank] = sort(rank);
    [~,best] = min(rank(randomRow),[],1);
    index1    = randomRow(best);
    pop2=pop(index1,:);
    %% cross
    if rand<cross_rate
        subPath = ocross(pop1(1,1:D), pop2(1,1:D));
       % subPath= eax_crossover(pop1(1,1:D), pop2(1,1:D),cost);
       % subPath = cycle_crossover(pop1(1,1:D), pop2(1,1:D));
     %   subPath=ex_crossover(pop1(1,1:D), pop2(1,1:D));
    else
        subPath=pop1(1,1:D);
    end
    %     if rand<cross_rate
    %         subPath =scxcross(pop1(1,1:D),pop2(1,1:D),distance1,distance2);
    %     else subPath=pop1(1,1:D);
    %     end
    %% mutation
    if rand<0.9
%    subPath = inmuta(subPath);
%         if size(cost,1)==195
%              subPath = stochastic_two_opt(subPath, cost);
%         else
     [count,subPath] = two_opt(subPath, cost,count);
%         disp('opt结束');
%         end
    else
        subPath=pop2(1,1:D);
        
    end
    %     if rand<(1-mutation_rate)
    %    subPath = two_opt(subPath, cost);
    %    end

offspring(k,:) = [subPath(1,:),subPath(1,1)];%%the new offspring
end

end

