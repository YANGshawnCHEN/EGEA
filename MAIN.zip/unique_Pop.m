function [Pop_1] = unique_Pop(pop,N)
%%%除去回环中的重复解   
    Pop1 = pop(:,1:N);
    Pop_new = zeros(size(Pop1,1),size(Pop1,2));
    for i = 1:size(Pop1,1)
        index_of_1 = find(Pop1(i, :) == 1);
        Pop_new(i,:) = [Pop1(i,index_of_1:end),Pop1(i,1:index_of_1-1)];
    end
    Pop_1 = [Pop_new,Pop_new(:,1),pop(:,N+2:end)];
    Pop_1 = unique(Pop_1,'rows');

    
end


