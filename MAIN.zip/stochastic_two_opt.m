function path = stochastic_two_opt(path, cost)
    % 随机扰动2-opt局部搜索
    % path: 当前路径
    % cost: 城市间的距离矩阵
    % max_iter: 最大扰动次数

    improved = true;
    iter = 0;
max_iter=200;
    while improved && iter < max_iter
        improved = false;
        iter = iter + 1;

        % 随机选择两个不同的城市
        i = randi([1, length(path)-1]);  % 随机选择城市i

        % 确保 j 的选取在合法范围内：即 j 必须大于 i + 1，并且 <= length(path)
        % 因此，最小值为 i + 2，最大值为 length(path)
        if i + 2 <= length(path)
            j = randi([i+2, length(path)]);  % 随机选择城市j（确保i < j）
        else
            % 如果 i + 2 超过路径的最后一个城市，则选择最远的 j
            j = length(path); 
        end

        % 计算交换前和交换后的路径长度
        % 注意：路径是以 1 到 N 的城市顺序表示，cost 矩阵是 1 基索引
        if i == length(path)  % 如果 i 是最后一个城市
            i_next = 1;
        else
            i_next = i + 1;
        end
        
        if j == length(path)  % 如果 j 是最后一个城市
            j_next = 1;
        else
            j_next = j + 1;
        end

        % 比较交换前后的路径长度
        if cost(path(i), path(i_next)) + cost(path(j), path(j_next)) > ...
           cost(path(i), path(j)) + cost(path(i_next), path(j_next))
            % 如果交换后路径更短，执行2-opt交换
            path(i+1:j) = fliplr(path(i+1:j));
            improved = true;
        end
    end
end