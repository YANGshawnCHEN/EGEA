function [Pop] = unique_sort(partical)
A = partical(:,1:end-1);
B=fliplr(A);

% 初始化一个空数组来存储相同行的行数
matching_rows = [];

% 比较矩阵A和B的每一行
for i = 1:size(A, 1)
    for j = 1:size(B, 1)
        if isequal(A(i, :), B(j, :))
            matching_rows = [matching_rows; i, j];
        end
    end
end
sort_matching = sort(matching_rows,2);
if isempty(sort_matching)
    Pop = partical;
else
    sort_matching_unique = unique(sort_matching,"rows");
    Pop1 = partical(sort_matching_unique(:,1),:);
    
    total = size(A,1);
    setd_num = setdiff(1:total,matching_rows);
    Pop2 = partical(setd_num,:);
    Pop = [Pop1;Pop2];
end


end