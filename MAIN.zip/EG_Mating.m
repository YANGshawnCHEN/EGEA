function [count,offspring]=EG_Mating(sumdistance,inter_cr,ls_r,topk,pop,count,varargin)
global cost;
[popsize,m]=size(pop);
D=m-1;
% inter_cr=0.9;%%取消传统交叉概率，交叉只区分谁是基准向量
% ls_r=0.9;%%取消变异参数，进行局部概率选择（精英选择）
offspring = zeros(popsize, D+1);
prob = ones(popsize, 1); % 构造概率，可以随便改
prob(1: ceil(popsize * 0.5)) = 3;
prob(1: ceil(popsize * 0.1)) = 6;
% prob = prob / sum(prob); % 非必须
%offspringCrossParents = reshape(randsample(1:popsize, 2*popsize, true, prob), popsize, 2);
%%
group1 = randsample(1:popsize, popsize, true, prob);
group2 = randsample(1:popsize, popsize, true, prob);
% 找到冲突位置
conflictIdx = (group1 == group2);
if any(conflictIdx)
    % 为冲突位置生成候选集（排除 group1 的对应值）
    candidates = arrayfun(@(x) setdiff(1:popsize, x), group1(conflictIdx), 'UniformOutput', false);
    % 对每个候选集，按修正后的概率采样
    % 注：cellfun 替代 for 循环
    newValues = cellfun(@(c) randsample(c, 1, true, prob(c)/sum(prob(c))), candidates);
    % 更新冲突位置的值
    group2(conflictIdx) = newValues;
end
offspringCrossParents=[group1;group2]';

offspringCrossParents = [offspringCrossParents, offspringCrossParents(:, 1) * 1000000 + offspringCrossParents(:, 2)];

% pop 是排序过的，这里假设默认依然排序，所以从上到下依次减少局部搜索的概率。
offspringCrossParents = sortrows(offspringCrossParents, 3);
% 假设只对前k个做局部
topk = ceil(D *topk);

for k=1:popsize
    p1ind = offspringCrossParents(k, 1);
    p2ind = offspringCrossParents(k, 2);
    parents1 = pop(p1ind, 1:D);
    parents2 = pop(p2ind, 1:D);

% idx = randperm(100, 2);
%   parents1 = pop(idx(1), 1:D);
%   parents2 = pop(idx(2), 1:D);

    %% cross 每一步都交叉 根据上述精英个体选择
    if rand<inter_cr %%选择交叉基准 
        subPath = ocross(parents1, parents2);
    else
   %  subPath = parents1;
     subPath = ocross(parents2, parents1);
    end
    
    % 对高分个体进行局部搜索 
    tmp_ls_r = ls_r * max(0, topk-k+1) / topk;
    if rand< tmp_ls_r
          [count,subPath] = two_opt(subPath,cost,count);
%%else
   %% subPath=parents2;
    end
    
%     if rand<0.9
%         subPath = inmuta(subPath);
%     else subPath=subPath;
%     end
%     
    offspring(k,:) = [subPath(1,:),subPath(1,1)];
end
end











