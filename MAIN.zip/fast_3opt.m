function optimized_tour = fast_3opt(parent1, parent2, dist_matrix, k)
    % 输入：
    % - parent1, parent2: 两个父代路径（开放或闭合格式）
    % - dist_matrix: 城市间距离矩阵
    % - k: 邻域剪枝范围（如k=30，仅检查后续k个城市）
    % 输出：优化后的闭合路径
    
    % --- 步骤1：生成初始解（示例：OX交叉合并父代） ---
    initial_tour = ocross(parent1, parent2);
    n = length(initial_tour);
    
    % --- 步骤2：剪枝3-opt优化 ---
    optimized_tour = initial_tour;
    max_attempts = 10;  % 连续无改进时终止
    attempts = 0;
    
    while attempts < max_attempts
        improvement = false;
        
        % 遍历每个城市作为起点i
        for i = 1:n-2
            % 限制j和l的搜索范围为i的后k个城市
            j_start = i + 1;
            j_end = min(i + k, n - 1);
            
            for j = j_start : j_end
                l_start = j + 1;
                l_end = min(j + k, n);
                
                for l = l_start : l_end
                    % 计算7种可能的3-opt重组方式
                    [new_tour, gain] = evaluate_3opt(optimized_tour, i, j, l, dist_matrix);
                    
                    if gain > 0
                        optimized_tour = new_tour;
                        improvement = true;
                        attempts = 0;  % 重置无改进计数器
                        break;
                    end
                end
                if improvement
                    break;
                end
            end
            if improvement
                break;
            end
        end
        
        if ~improvement
            attempts = attempts + 1;
        end
    end
    
    % --- 步骤3：闭合路径 ---
    optimized_tour = [optimized_tour, optimized_tour(1)];
end

% 辅助函数：评估3-opt的7种重组方式并返回最优解
function [best_tour, max_gain] = evaluate_3opt(tour, i, j, l, dist_matrix)
    % 提取原始边距离
    a = tour(i); b = tour(i+1);
    c = tour(j); d = tour(j+1);
    e = tour(l); f = tour(l+1);
    original_cost = dist_matrix(a,b) + dist_matrix(c,d) + dist_matrix(e,f);
    
    % 7种重组方式
    candidates = cell(7, 1);
    gains = zeros(7, 1);
    
    % 方式1: 反转 j+1 到 l
    new_tour = [tour(1:i), tour(j+1:l), tour(i+1:j), tour(l+1:end)];
    candidates{1} = new_tour;
    gains(1) = original_cost - (dist_matrix(a, tour(j+1)) + dist_matrix(tour(i+1), tour(l)) + dist_matrix(d, e));
    
    % 方式2-7: 其他重组方式（需完整实现）
    % ...
    
    % 选择增益最大的重组方式
    [max_gain, idx] = max(gains);
    best_tour = candidates{idx};
end