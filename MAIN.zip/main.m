
clc;

clear
global cost
%  问题数据
allFileNames = {
  'att48.tsp'
%   'eil51.tsp'
%     'berlin52.tsp'
%  'st70.tsp'
%  'eil76.tsp'
%   'pr76.tsp'
%   'rat99.tsp'
%  'kroA100.tsp'
%   'kroB100.tsp'
%   'rd100.tsp'
%   'eil101.tsp'
%   'pr107.tsp'
%     'pr124.tsp'
%  'ch130.tsp'
% 'ch150.tsp'
%  'pr152.tsp'
%   'd198.tsp'
%   'kroA200.tsp'
%    'kroB200.tsp'
%        'ts225.tsp'
%      'tsp225.tsp'
%     'gil262.tsp'
%         'a280.tsp'
%      'lin318.tsp'
%                'rd400.tsp'
%                         'fl417.tsp'
%                 'pr439.tsp'
%                     'rat575.tsp'
%                            'rat783.tsp'
%                                  'fl1400.tsp' 
}


%%对比算例  参数比较等等
   
%      'eil51.tsp'
%     'berlin52.tsp'
%     'eil76.tsp'
%     'pr76.tsp'
%     'rat99.tsp'
%     'kroA100.tsp'
%     'pr107.tsp'
%  'ch130.tsp'
%   'ch150.tsp'
%    'pr152.tsp'
%     'd198.tsp'
%      'kroA200.tsp'
%        'ts225.tsp'
%         'tsp225.tsp'
    % 添加更多文件名...
%     };
%G=[33522;426;7542;675;538;108159;1211;21282;22141;7910;629;44303;59030;]
  % G=[6110;6528;73682;15780;29368;29437;126643;3916;2378;2579;42029;15281;11861;107217;6773;8806;20127];
% G=[426;7542;538;108159;1211;21282;44303;6110;6528;73682;15780;29368;126643;3916];%%整合参数检验的最优值
  % %%
  G=[33522];
% G=[426;7542;538;108159;1211;21282;44303;6110;6528;73682;15780;29368;126643;3916];
numFiles = numel(allFileNames);
allPositions = cell(1, numFiles);  % 创建空元胞数组
for idx = 1:numFiles
    currentFile = allFileNames{idx};  % 获取当前文件名
    position = importdata(currentFile);
    position=position(:,2:3);
    %MaxFes = 60000;
    
    city_num = size(position,1);     % 城市数量（维度）
    MaxFes = 5000*city_num;
    % 计算城市与城市之间的距离矩阵
    cost = zeros(city_num,city_num);
    % for i = 1:city_num
    %     for j = 1:city_num
    %         cost(i,j) = sqrt((position(i,1)-position(j,1))^2+(position(i,2)-position(j,2))^2);
    %         cost = round(cost);
    %     end
    % end
    cost = sqrt((position(:,1) - position(:,1)').^2 + (position(:,2) - position(:,2)').^2);
    cost = round(cost);
    
    M = 1;              % 目标数量
    N = city_num;       % 城市数量（维度）
    Popsize =100;
    
    % 记录算法执行的时间
    topk=0.15;
    ls_r=0.3;
    pc=0.3;
    for run=1:31
        tic;
        [pspf]= tsp(pc,ls_r,topk,M,N,MaxFes,Popsize);      % 调用算法函数
        result(run)=pspf(1,end)
        time_over= toc;
        result_time (run)= time_over;    % 记录算法执行的时间
        disp(['执行时间：', num2str(time_over), ' 秒']);
    end
%     zx(idx)=min(result);
%     zd(idx)=max(result);
    pj(idx)=mean(result);
    bz(idx)=std(result);
    PDB(idx)=(min(result)-G(idx))/G(idx);
    PDA(idx)=(mean(result)-G(idx))/G(idx);
    Yi(idx)=mean(result_time);
    JG(idx,:)=result;
end
% % save  ga_2opt result
% zx=zx';
%     zd=zd';
%     pj=pj';
%     bz=bz';
    PDB=PDB';
    PDA=PDA';
    Yi=Yi';
    JG=JG';
    
    
    
    save zuizhong_final_no17
    
% load pc03
    
    
    
    
    

% 
% position = importdata('eil101.tsp');  % 加载位置信息
% position=position(:,2:3);
% MaxFes = 60000;
% 
% city_num = size(position,1);     % 城市数量（维度）
% MaxFes = 1000*city_num;
% 计算城市与城市之间的距离矩阵
% cost = zeros(city_num,city_num);
% for i = 1:city_num
%     for j = 1:city_num
%         cost(i,j) = sqrt((position(i,1)-position(j,1))^2+(position(i,2)-position(j,2))^2);
%         cost = round(cost);
%     end
% end
% cost = sqrt((position(:,1) - position(:,1)').^2 + (position(:,2) - position(:,2)').^2);
% cost = round(cost);
% 
% M = 1;              % 目标数量
% N = city_num;       % 城市数量（维度）
% Popsize =100;
% 
% 记录算法执行的时间
% for run=1:30
%     tic;
%     [pspf]= tsp(M,N,MaxFes,Popsize);      % 调用算法函数
%     result(run)=pspf(1,end)
%     time_over= toc;
%     result_time (run)= time_over;    % 记录算法执行的时间
%     disp(['执行时间：', num2str(time_over), ' 秒']);
% end
% min(result)
% max(result)
% mean(result)
% std(result)
% PDB=(min(result)-629)/629
% PDA=(mean(result)-629)/629
% mean(result_time)



% save  ga_2opt result
%save  egga_eil76 result

%
%
% % 假设 cost 是 N x N 距离矩阵
% Y = squareform(cost);            % 将距离矩阵转换为向量形式
% Z = linkage(Y, 'average');       % 层次聚类
% k = 10;                          % 假设想划分成10个区域
% T = cluster(Z, 'maxclust', k);   % 得到每个城市所属的簇标签
%
% % 按簇处理每个子图
% for i = 1:k
%     idx = find(T == i);                 % 第i个簇包含的城市索引
%     subCost = cost(idx, idx);          % 提取该簇的子距离矩阵
% %     subTour = solveTSP(subCost);       % 用遗传算法或2-opt等求TSP
%     N=size(subCost,1);
%     [pspf]= tsp1(subCost,M,N,MaxFes,Popsize);
%     ind=idx';
%     globalSubTour{i}= ind(pspf(1,1:end-2));
%     % 保存 idx 和子路径，后面拼接
% end
% mergedPath = [];
% for j = 1:length(globalSubTour)
%     mergedPath = [mergedPath, globalSubTour{j}];
% end
%
%
