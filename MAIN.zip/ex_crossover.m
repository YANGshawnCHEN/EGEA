function child = ex_crossover(parent1, parent2)
% ERX Crossover for TSP
% parent1, parent2: 两个父路径（1xN 数组，表示城市顺序）
% child: 子路径（1xN）

    N = length(parent1);
    edge_map = build_edge_map(parent1, parent2);

    visited = false(1, N);
    child = zeros(1, N);

    % 随机选一个起点
    current = parent1(randi(N));
    child(1) = current;
    visited(current) = true;

    for i = 2:N
        % 从邻接表中移除当前城市
        edge_map = remove_city_from_map(edge_map, current);

        % 选择下一个城市
        neighbors = edge_map{current};
        if ~isempty(neighbors)
            % ✅ 使用 arrayfun 而非 cellfun
            degrees = arrayfun(@(x) length(edge_map{x}), neighbors);
            [~, idx] = min(degrees);
            next_city = neighbors(idx);
        else
            % 无邻居时，从未访问城市中随机选一个
            unvisited = find(~visited);
            next_city = unvisited(randi(length(unvisited)));
        end

        child(i) = next_city;
        visited(next_city) = true;
        current = next_city;
    end
end

function edge_map = build_edge_map(p1, p2)
    N = length(p1);
    edge_map = cell(1, N);
    for i = 1:N
        city = p1(i);
        edge_map{city} = unique([get_neighbors(p1, i), get_neighbors(p2, find(p2 == city))]);
    end
end

function neighbors = get_neighbors(path, idx)
    N = length(path);
    prev = path(mod(idx - 2, N) + 1);  % 前一个城市（循环）
    next = path(mod(idx, N) + 1);      % 后一个城市（循环）
    neighbors = [prev, next];
end

function edge_map = remove_city_from_map(edge_map, city)
    % 从所有邻接表中移除已访问城市
    for i = 1:length(edge_map)
        edge_map{i}(edge_map{i} == city) = [];
    end
end