function child = erx_crossover(parent1, parent2)
    % 输入：两个父代路径（开放或闭合路径均可）
    % 输出：闭合的子代路径
    
    % --- 1. 输入处理与验证（确保路径合法）---
    % 处理闭合路径
    if parent1(1) == parent1(end)
        parent1 = parent1(1:end-1);
    end
    if parent2(1) == parent2(end)
        parent2 = parent2(1:end-1);
    end
    
    % 验证开放路径是否为排列（无重复城市）
    if length(unique(parent1)) ~= length(parent1) || length(unique(parent2)) ~= length(parent2)
        error('输入路径非法：存在重复城市');
    end
    
    n = length(parent1);
    if n ~= length(parent2)
        error('输入路径长度不一致');
    end
    
    % --- 2. 边表构建（修正前驱/后继计算）---
    edgeTable = containers.Map('KeyType', 'double', 'ValueType', 'any');
    
    % 辅助函数：返回前驱和后继节点（以元胞数组形式）
    getPrevNext = @(path, idx) { 
        path(mod(idx-2, n) + 1),  % 前驱（MATLAB索引从1开始）
        path(mod(idx, n) + 1)      % 后继
    };
    
    % 填充父代1的边表
    for i = 1:n
        city = parent1(i);
        pn = getPrevNext(parent1, i);
        if ~isKey(edgeTable, city)
            edgeTable(city) = [];
        end
        edgeTable(city) = unique([edgeTable(city), pn{1}, pn{2}]);
    end
    
    % 填充父代2的边表
    for i = 1:n
        city = parent2(i);
        pn = getPrevNext(parent2, i);
        if ~isKey(edgeTable, city)
            edgeTable(city) = [];
        end
        edgeTable(city) = unique([edgeTable(city), pn{1}, pn{2}]);
    end
    
    % --- 3. 生成子代路径（开放路径）---
    child = zeros(1, n);
    remaining = parent1;  % 剩余未访问城市
    
    % 随机选择起始城市
    current = randsample(remaining, 1);
    child(1) = current;
    remaining = remaining(remaining ~= current);  % 安全移除
    
    % 逐步构建子代
    for i = 2:n
        neighbors = edgeTable(current);
        validNeighbors = intersect(neighbors, remaining);
        
        if ~isempty(validNeighbors)
            % 选择邻接边最少的城市（若有多个，随机选择）
            counts = cellfun(@(x) length(edgeTable(x)), num2cell(validNeighbors));
            [~, idx] = min(counts);
            nextCity = validNeighbors(idx(randi(length(idx))));
        else
            % 确保remaining非空后随机选择
            if isempty(remaining)
                error('逻辑错误：remaining为空，无法选择下一个城市');
            end
            nextCity = randsample(remaining, 1);
        end
        
        % 检查nextCity是否在remaining中（防止逻辑错误）
        if ~ismember(nextCity, remaining)
            error('逻辑错误：nextCity不在remaining中');
        end
        
        child(i) = nextCity;
        remaining = remaining(remaining ~= nextCity);  % 安全移除
        current = nextCity;
    end
end