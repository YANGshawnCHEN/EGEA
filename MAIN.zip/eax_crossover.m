function child = eax_crossover(parent1, parent2, distance_matrix)
    num_cities = length(parent1);
    
    % 提取父代的边集合（无向边）
    edges1 = get_edges(parent1);
    edges2 = get_edges(parent2);
    
    % 合并边并构建AB环
    common_edges = intersect(edges1, edges2, 'rows');
    union_edges = union(edges1, edges2, 'rows');
    
    % 随机选择AB环（简化：随机选择共同边构建子代）
    if ~isempty(common_edges)
        selected_edges = common_edges(randperm(size(common_edges,1), min(10, size(common_edges,1))), :);
    else
        selected_edges = union_edges(randperm(size(union_edges,1), 10), :);
    end
    
    % 构建子代路径（贪心填充）
    child = zeros(1, num_cities);
    remaining_cities = 1:num_cities;
    current_city = selected_edges(1, 1);
    child(1) = current_city;
    remaining_cities(remaining_cities == current_city) = [];
    
    for i = 2:num_cities
        % 查找当前城市在selected_edges中的连接
        candidates = selected_edges(selected_edges(:,1) == current_city, 2);
        candidates = [candidates; selected_edges(selected_edges(:,2) == current_city, 1)];
        candidates = intersect(candidates, remaining_cities);
        
        if ~isempty(candidates)
            % 选择最近的下一个城市
            [~, idx] = min(distance_matrix(current_city, candidates));
            next_city = candidates(idx);
        else
            % 随机选择未访问城市
            next_city = remaining_cities(randi(length(remaining_cities)));
        end
        
        child(i) = next_city;
        current_city = next_city;
        remaining_cities(remaining_cities == next_city) = [];
    end
end

function edges = get_edges(path)
    edges = [path(1:end-1); path(2:end)]';
    edges = [edges; path(end), path(1)]; % 闭合路径
    edges = sort(edges, 2); % 无向边标准化
    edges = unique(edges, 'rows');
end