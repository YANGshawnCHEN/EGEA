function [u]= inmuta(u)
[~,py]=size(u);
m1=ceil(rand*py);
m2=ceil(rand*py);
while m1>=m2
    m2=ceil(rand*py);
    if m1==py
      m1=ceil(rand*py);
    end
end
h=(m2-m1)/2;
m1=m1+1;
for k=1:h
    L=u(m1+k);
    u(m1+k)=u(m2-k);
    u(m2-k)=L;
end