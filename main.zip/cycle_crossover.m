function child = cycleCrossover(parent1, parent2)
% CYCLECROSSOVER 执行循环交叉（CX）
% 输入: parent1, parent2 - 两个长度相同的父代排列向量
% 输出: child - 交叉后生成的子代排列

    n = length(parent1);
    child = zeros(1, n);       % 初始化子代
    cycle = false(1, n);       % 标记当前循环中的位置
    index = 1;

    % Step 1: 找到第一个循环
    while ~cycle(index)
        cycle(index) = true;
        index = find(parent1 == parent2(index));
    end

    % Step 2: 将循环中的位置从 parent1 复制到子代
    for i = 1:n
        if cycle(i)
            child(i) = parent1(i);
        else
            child(i) = parent2(i);
        end
    end
end