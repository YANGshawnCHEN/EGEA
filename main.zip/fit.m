function [s] = fit(pop,M,N,cost)
if size(pop,2) ~= (N+1)
    error ('种群的列数应等于问题维度+1')
end
if N ~= size(cost,1)
    error ('问题维度与cost矩阵不匹配')
end

s=zeros(size(pop,1),M); % S中存储了目标空间的值
for j=1:size(pop,1)
    for i=1:N
        for k=1:M
            s(j,k)=s(j,k)+cost(pop(j,i),pop(j,i+1));
        end
    end
	
end
end