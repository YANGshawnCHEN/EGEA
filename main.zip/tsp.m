function [pspf] = tsp(inter_cr,ls_r,topk,M,N,MaxFes,Popsize)
global cost;
% pspf 矩阵，例如：1-2-3-4-1-目标值
sigma2_max=1e-6;
count = 0;
%%
Dim=size(cost,1);
%%维度大于190还是从交叉上下手，先用O再用ERX；
% if Dim>190 | Dim<20
%     Popsize=300;
% else
%     Popsize=100;
% end

Pop=zeros(Popsize,N+1); % generate populations
for i=1:Popsize
    Pop(i,1:N)=randperm(N);
    Pop(i,N+1)=Pop(i,1);
end
% pop必须从1开始，城市的序号，如1-2-3-4-1

[s]=fit(Pop,M,N,cost);       % 调用目标计算函数
count = count+size(Pop,1);

partical = [Pop,s];      % 
[FrontNo,MaxFNo] = NDSort(s,Popsize);

%%替换NDSort
[~, ~, unique_ranks] = unique(s, 'sorted');
ranks = unique_ranks';





fDS=zeros(1,Popsize);

stop_condition = false;
while ~stop_condition
%%
% sigma2 = var(s);  % 计算适应度方差
% sigma2 = max(sigma2, 1e-6); % 设置最小方差阈值
% sigma2_max = max(sigma2, sigma2_max); % 更新历史最大值
% %mutation_rate= 0.4 + (0.9 - 0.4) * (1 - sigma2/sigma2_max);%
%  mutation_rate= 0.2 + (0.9 - 0.2) * (count)/MaxFes;
% % cross_rate=0.9;
%  [offspring]=GA(s,Pop,FrontNo,fDS);  % generate offspring
  [count,offspring]=EG_Mating(s,inter_cr,ls_r,topk,Pop,count,FrontNo,fDS);  % generate offspring
    
    % off1=unique(offspring,'rows');        % 
    offspring=[Pop;offspring];
    offspring=unique(offspring,'rows');        % 


    count = count+size(offspring,1);


    if count >= MaxFes          % 算法中确保总评价次数不超过MaxFes
        stop_condition = true;
    end
        [s1]=fit(offspring,M,N,cost);         % 
    partical = [offspring,s1];
    partical = sortrows(partical,N+2);

    partical=unique(partical,'rows');
    partical = sortrows(partical,N+2);
    if size(partical,1) > Popsize
        partical = partical(1:Popsize,:);
    end

    Pop = partical(:,1:end-1);
    s = partical(:,end);

    minvalue = min(partical(:,end));    
end


partical = unique_Pop(partical,N);
partical = unique_sort(partical);
partical = sortrows(partical,N+2);

pspf = partical;
end

