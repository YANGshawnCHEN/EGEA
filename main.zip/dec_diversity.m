function [b]=dec_diversity(varargin)
Pop=varargin{1};
[n,m]=size(Pop);
if nargin==1
    [N,~]=size(Pop);
    PS=Pop;
else if nargin==2;
    PS=varargin{2};
    [N,~]=size(PS);
    end
end
b=zeros(n,N);
w=zeros(n,N);
for i=1:n
    for k=1:N
        a=zeros(m-1,m-1);
 
        for j=1:m-1
            if Pop(i,j)==PS(k,j)
                w(i,k)=w(i,k)+1;
            end
            a(Pop(i,j),Pop(i,j+1))=1;
            a(Pop(i,j+1),Pop(i,j))=1;
            a(PS(k,j),PS(k,j+1))=a(PS(k,j),PS(k,j+1))+1;
            a(PS(k,j+1),PS(k,j))=a(PS(k,j+1),PS(k,j))+1;
            [x,~]=size(find(a==2));
        b(i,k)=x/2;
%             t=find(Pop(i,j)==PS(k,:));
%             if any(t==m)
%                 if Pop(i,j+1)==PS(k,m-1)%%�䲻�������һ��λ��
%                      b(i,k)=b(i,k)+1;
%                 else if Pop(i,j+1)==PS(k,2)%%�䲻���ڵ�һ��λ��
%                       b(i,k)=b(i,k)+1;
%                      else continue;
%                     end
%                 end
%             elseif Pop(i,j+1)==PS(k,t+1)|| Pop(i,j+1)==PS(k,t-1)
%                  b(i,k)=b(i,k)+1;
%             end
        end
    end
end
% b=power(b,w);
% b=b.*w;
b=power(2,b)+power(2,w);
b=1-b/max(max(b));